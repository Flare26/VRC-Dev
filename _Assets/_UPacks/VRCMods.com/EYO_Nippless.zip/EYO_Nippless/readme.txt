INGO CHANNEL様より販売されている「イヨ」用のニップレスです。
露出高い服ばっか作ってるのであったほうが良いかなと思ってぱぱっと作りました。
支援版とか置かないのでよかったら別の服とか買ってください。
タダなので好きに使ってください。

オリジナルアバター「イヨ」：JINGO CHANNEL 様
https://booth.pm/ja/items/2630437


■内容物
ニップレス ▲484
texture 

■導入手順
AvatarToolsを使用してください。

AvatarTools：黒鳥ケモノ工房　黒鳥 様
https://kurotori.booth.pm/items/1564788


シェイプキーをvrchat内でいじりたい場合は
unity内の
EYO\EYO3.0\Toggle
のbreast_big breast_flatにシェイプキーを追加してください

■利用規約
https://www.dropbox.com/s/mm4jk7sjp3cdv5b/20210318070029vn3license.pdf?dl=0

■更新履歴
2021/06/13
公開