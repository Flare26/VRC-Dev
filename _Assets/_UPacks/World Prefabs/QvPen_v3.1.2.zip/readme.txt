「QvPen」

・概要 --------------------------------
VRChatのワールド用のトレイルペンセットです(VRCSDK3-UDON向けです)。

詳しくはBOOTHのページを参照してください。

・必須アセット(予めインポートしておく必要があります)
●VRCSDK3-UDON
- https://vrchat.com/home/download
●UdonSharp - by MerlinVR
- https://github.com/MerlinVR/UdonSharp/releases/latest

・配布URL -----------------------------
- https://65536.booth.pm/items/1555789
- https://booth.pm/ja/items/1555789

・お借りしたもの --------------------------
●rounded_trail - phi16
- https://github.com/phi16/VRC_storage#rounded_trail (LICENSE : CC0)
以上を改変して使用させていただいています。

・利用規約 -----------------------------
●内容物を使用して生じたいかなる問題に対しても当ファイルの作者は一切の責任を負いません。
●VRChatのワールドに組み込む事以外は再配布をしないでください。

・作者 --------------------------------
●ペンモデル
powass

●実装・Prefab作成
ureishi
● Twitter
- https://twitter.com/intent/user?user_id=754907745065709569
