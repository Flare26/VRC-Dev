Thank you for downloading my Udon Video Player prefab!

For installation instructions, please visit my website https://vrchat.nishawolfe.com/prefabs/videoplayer

This software falls under the CC BY-SA License, please review LICENSE.txt for details.